export const siteConfig = {
  brandName: "AUTO SPORT",
  companyName: "AUTO SPORTS CAR CARE",
  legalCompany: null,
  currency: "AED",
  country: "AE",
  locale: "en-AE",
  originalLogo: "/original-logo.png",
  phone: null,
  whatsapp: null,
  email: null,
  socials: [],
  storeLocations: [],
} as const;
